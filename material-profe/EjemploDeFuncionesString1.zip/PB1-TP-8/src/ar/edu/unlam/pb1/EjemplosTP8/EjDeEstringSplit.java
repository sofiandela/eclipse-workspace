package ar.edu.unlam.pb1.EjemplosTP8;

public class EjDeEstringSplit {

	public static void main(String[] args) {
		String colores = "blanco,rojo,blanco,azul,amarillo,azul";
		String arrayColores[ ] = colores.split(",");

		// Aqu� ya tenemos un array en el que cada elemento es un color.
System.out.println("Declaro una cadena de colores separados por coma:");
System.out.println(colores);
System.out.println("Aplico la funci�n split que separa por coma");
for (int i = 0; i < arrayColores.length; i++) {
		       System.out.println(arrayColores[i]);
		}
	}

}
