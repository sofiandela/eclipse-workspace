package ar.edu.unlam.pb1.EjemplosTP8;

import java.util.Scanner;

public class DeLaClaseString {

	public static void main(String[] args) {
//Ejemplo de charAt (int index)
		Scanner teclado= new Scanner(System.in);
		String palabra=" ";
		System.out.println("Ingrese una palabra");
		palabra=teclado.next();
		System.out.println("Muestro la primera letra "+palabra.charAt(0));
		System.out.println("Muestro la segunda letra "+palabra.charAt(1));
		System.out.println("Muestro la tercera letra "+palabra.charAt(2));
		System.out.println("Muestro la tercera letra "+palabra.charAt(3));
	System.out.println("�Que muestra la funci�n length?");
	System.out.println("devuelve el tama�o "+palabra.length());
	}

}
