package ar.edu.unlam.pb1.EjemplosTP8;

import java.util.Scanner;

public class EjStringTrim {

	public static void main(String[] args) {
		Scanner teclado= new Scanner(System.in);
		String oracion=" ";
		System.out.println("Ingrese una oraci�n");
		oracion=teclado.nextLine();
		System.out.println("Elimina el espacio inicial");
		System.out.println(oracion.trim());
	}

}
