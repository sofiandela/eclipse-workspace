package ar.edu.unlam.pb1.EjemplosTP8;

import java.util.Scanner;

public class DeLaClaseStringSubcadenaCortar {

	public static void main(String[] args) {
		//Ejemplo de subString
		String cadenaUno=" ";
		Scanner teclado = new Scanner(System.in);
		System.out.println("Ingrese una cadena cualquiera");
		cadenaUno= teclado.nextLine();
		System.out.println("Muestro la cadena " +cadenaUno);
		//Vamos a mostrar ahora un subString
		System.out.println("La sub cadena es: " + cadenaUno.substring(0, 7));
	
	}
}
