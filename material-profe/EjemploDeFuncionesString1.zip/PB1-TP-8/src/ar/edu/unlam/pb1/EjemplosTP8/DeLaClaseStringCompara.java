package ar.edu.unlam.pb1.EjemplosTP8;

public class DeLaClaseStringCompara {

	public static void main(String[] args) {
		//Como funciona el equals
		String cadenaUno= "ahora";
		String cadenaDos= "Ahora";
		if (cadenaUno.equals(cadenaDos))
		System.out.println("las cadenas son iguales");
		else
		System.out.println("las cadenas no son iguales");
		//Como funciona el equalsIgnoreCase
		String cadenaTres= "solamente";
		String cadenaCuatro= "SoLaMenTe";
		if (cadenaTres.equalsIgnoreCase(cadenaCuatro))
		System.out.println("las cadenas son iguales "+ cadenaTres 
				+"y "+ cadenaCuatro );
		else
		System.out.println("las cadenas no son iguales");
	}

}
